export const events = [
  {
    id: 1,
    name: "Music Festival",
    date: "2023-04-15",
    time: "12:00 PM",
    place: "Central Park",
    shortDescription: "Live music by popular bands.",
    description:
      "Join us for a day of live music by popular bands from around the world. Food and drinks will be available for purchase.",
    price: 25,
    isFree: false,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "XYZ Productions",
  },
  {
    id: 2,
    name: "Art Exhibition",
    date: "2023-04-20",
    time: "11:00 AM",
    place: "Museum of Modern Art",
    shortDescription: "Explore contemporary art by local artists.",
    description:
      "This exhibition features the works of local artists and explores contemporary art. Join us for a day of art, music and refreshments.",
    price: 0,
    isFree: true,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Artists Association",
  },

  {
    id: 3,
    name: "Food Festival",
    date: "2023-05-05",
    time: "2:00 PM",
    place: "Downtown Square",
    shortDescription: "Experience the best food in town.",
    description:
      "Join us for a day of amazing food from the best restaurants in town. There will be live music and games for all ages.",
    price: 20,
    isFree: false,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Food Lovers Association",
  },
  {
    id: 4,
    name: "Comedy Night",
    date: "2023-05-10",
    time: "8:00 PM",
    place: "The Comedy Club",
    shortDescription: "Laugh out loud with hilarious comedians.",
    description:
      "Join us for a night of laughter with some of the funniest comedians in the city. Food and drinks will be available for purchase.",
    price: 15,
    isFree: false,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "The Comedy Club",
  },
  {
    id: 5,
    name: "Movie Night",
    date: "2023-05-15",
    time: "7:00 PM",
    place: "Central Park",
    shortDescription: "Enjoy a classic movie under the stars.",
    description:
      "Join us for a night of classic movies under the stars. Bring your own blankets and snacks.",
    price: 0,
    isFree: true,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Film Association",
  },
  {
    id: 6,
    name: "Sports Tournament",
    date: "2023-05-20",
    time: "10:00 AM",
    place: "Sports Complex",
    shortDescription: "Compete in a fun sports tournament.",
    description:
      "Join us for a day of friendly competition in various sports. There will be prizes and refreshments for all participants.",
    price: 10,
    isFree: false,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Sports Association",
  },
  {
    id: 7,
    name: "Fashion Show",
    date: "2023-06-05",
    time: "6:00 PM",
    place: "Convention Center",
    shortDescription: "Experience the latest fashion trends on the runway.",
    description:
      "Join us for a night of fashion as models showcase the latest designs from top designers. Food and drinks will be available for purchase.",
    price: 30,
    isFree: false,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Fashion Association",
  },
  {
    id: 8,
    name: "Science Fair",
    date: "2023-06-10",
    time: "9:00 AM",
    place: "Convention Center",
    shortDescription: "Explore the latest scientific advancements.",
    description:
      "Join us for a day of learning as scientists showcase their latest research and discoveries. There will be interactive exhibits and activities for all ages.",
    price: 0,
    isFree: true,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Science Association",
  },
  {
    id: 9,
    name: "Charity Auction",
    date: "2023-06-15",
    time: "7:00 PM",
    place: "Art Gallery",
    shortDescription: "Bid on unique items to support a good cause.",
    description:
      "Join us for a night of charity as we auction off unique items to raise money for a good cause. Food and drinks will be available for purchase.",
    price: 50,
    isFree: false,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Charity Association",
  },
  {
    id: 10,
    name: "Technology Conference",
    date: "2023-06-20",
    time: "8:00 AM",
    place: "Convention Center",
    shortDescription:
      "Discover the latest trends and innovations in technology.",
    description:
      "Join us for a day of learning as experts discuss the latest trends and innovations in technology. There will be interactive exhibits and networking opportunities.",
    price: 100,
    isFree: false,
    photos: [
      "https://via.placeholder.com/400x300?text=Event+Photo+1",
      "https://via.placeholder.com/400x300?text=Event+Photo+2",
    ],
    organizer: "Tech Association",
  },
];

console.log(events);
