import "./App.css";
import EventsSearch from "./Pages/EventsSearch";
import Homepage from "./Pages/Homepage";
import LoginForm from "./Pages/LoginForm";
import SignupForm from "./Pages/SignupForm";
import { NavLink, Route, Routes, BrowserRouter } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <div className="nav-bar">
          <NavLink className="nav-link" to="/">
            HomePage
          </NavLink>
          <NavLink className="nav-link" to="/signup">
            Signup
          </NavLink>
          <NavLink className="nav-link" to="/login">
            Login
          </NavLink>
          <NavLink className="nav-link" to="/event-search">
            Events
          </NavLink>
        </div>
        <Routes>
          <Route path="/signup" element={<SignupForm></SignupForm>} />
          <Route path="/login" element={<LoginForm></LoginForm>} />

          <Route path="/" element={<Homepage></Homepage>} />
          <Route path="/event-search" element={<EventsSearch></EventsSearch>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
