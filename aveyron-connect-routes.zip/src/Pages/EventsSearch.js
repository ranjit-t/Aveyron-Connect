import React, { useState } from "react";
import { events } from "../Data/Events";
import "./EventsSearch.css";

const EventsSearch = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchLocation, setSearchLocation] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [eventsPerPage] = useState(5);

  // Filter events based on search terms
  const filteredEvents = events.filter(
    (event) =>
      event.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      event.place.toLowerCase().includes(searchLocation.toLowerCase())
  );

  // Pagination logic
  const indexOfLastEvent = currentPage * eventsPerPage;
  const indexOfFirstEvent = indexOfLastEvent - eventsPerPage;
  const currentEvents = filteredEvents.slice(
    indexOfFirstEvent,
    indexOfLastEvent
  );
  const totalPages = Math.ceil(filteredEvents.length / eventsPerPage);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div className="events-search">
      <h2 className="events-search__heading">Events Search</h2>
      <div className="events-search__filters">
        <input
          type="text"
          placeholder="Search by name"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="events-search__input"
        />
        <input
          type="text"
          placeholder="Search by location"
          value={searchLocation}
          onChange={(e) => setSearchLocation(e.target.value)}
          className="events-search__input"
        />
        <button className="events-search__button">Search</button>
      </div>
      <div className="events-search__results">
        {currentEvents.map((event) => (
          <div key={event.id} className="event">
            <img
              src={event.photos[0]}
              alt={event.name}
              className="event__photo"
            />
            <h3 className="event__heading">{event.name}</h3>
            <p className="event__info">
              <strong>Date:</strong> {event.date}
            </p>
            <p className="event__info">
              <strong>Time:</strong> {event.time}
            </p>
            <p className="event__info">
              <strong>Place:</strong> {event.place}
            </p>
            <p className="event__info">{event.shortDescription}</p>
            <p className="event__info">
              <strong>Price:</strong>{" "}
              {event.isFree ? "Free" : `$${event.price}`}
            </p>
            <button className="event__button">More Info</button>
          </div>
        ))}
      </div>
      <div className="events-search__pagination">
        {totalPages > 1 &&
          Array.from({ length: totalPages }).map((_, index) => (
            <button
              key={index}
              onClick={() => paginate(index + 1)}
              className="events-search__page"
            >
              {index + 1}
            </button>
          ))}
      </div>
    </div>
  );
};

export default EventsSearch;
